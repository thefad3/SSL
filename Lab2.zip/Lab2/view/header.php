<?php
/**
 * Created by PhpStorm.
 * User: chrismac
 * Date: 11/24/14
 * Time: 11:12 AM
 */
/** Accomodate for foundation when creating the outer front end */


?>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/foundation.css" />
    <script src="../js/vendor/modernizr.js"></script>
</head>
<body>
<div class="row">
    <div class="large-12 medium-12 columns" id="formStyle">
        <a href="index.php">Home</a> -
        <a href="/index.php?action=registerForm">Register</a> -
        <a href="/index.php?action=loginForm">Login</a>
    </div>
</div>
