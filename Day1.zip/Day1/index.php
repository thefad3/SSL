
<?php
/**
 * Created by PhpStorm.
 * User: chrismac
 * Date: 11/24/14
 * Time: 10:28 AM
 */
/*
$myvar = "joe"
$myvar = array("name"=>"joe")

foreach($myvar as $x){
    $myarr[$x];
}

function getname(){

}
*/

//MVC Now
//echo "Hello World!";

include("controllers/homecontroller.php");



?>

