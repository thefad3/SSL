<?php
/**
 * Created by PhpStorm.
 * User: chrismac
 * Date: 11/24/14
 * Time: 11:12 AM
 */



?>
<html>
<head>
    <title>THis is a title</title>
</head>
<body>

<nav>
    <a href="index.php">Home</a>
    <a href="/index.php?action=registerForm">Register form</a>
</nav>
