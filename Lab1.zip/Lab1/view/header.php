<?php
/**
 * Created by PhpStorm.
 * User: chrismac
 * Date: 11/24/14
 * Time: 11:12 AM
 */
/** Accomodate for foundation when creating the outer front end */


?>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="../css/foundation.css" />
    <script src="../js/vendor/modernizr.js"></script>
</head>
<body>
<nav>
    <a href="index.php">Home</a>
    <a href="/index.php?action=registerForm">register form</a>
</nav>
