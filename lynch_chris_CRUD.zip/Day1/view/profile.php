<?php
/**
 * Created by PhpStorm.
 * User: chrismac
 * Date: 12/2/14
 * Time: 7:09 PM
 */



var_dump($_SESSION);

echo '<img src="/uploads/'.$_SESSION['img'].'">';
?>

