<?


?>

<div class="row">
    <div class="large-12 medium-12 columns">

    <form enctype="multipart/form-data" action="index.php?action=updateAction" method="POST">
        <label>Username</label>
        <input type="text" name="username" value=""><br>
        <label>Password</label>
        <input type="password" name="password" value=""><br>
        <button type="submit" value="Send File">Login</button>
    </form>
</div>
</div>
