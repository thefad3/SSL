<?php
/**
 * Created by PhpStorm.
 * User: chrismac
 * Date: 11/24/14
 * Time: 11:12 AM
 */



?>
<html>
<head>
    <link rel="stylesheet" href="css/foundation.css" />
    <script src="js/vendor/modernizr.js"></script>
    <title>MVC Application</title>
</head>
<body>
<div class="row">
    <div class="large-12 medium-12 columns">
    <a href="index.php">Home</a> |
    <a href="index.php?action=addUserForm">Add User Form</a> |
    <a href="/index.php">Login</a>
</div>
    </div>
<script src="js/vendor/jquery.js"></script>
<script src="js/foundation.min.js"></script>
<script>
    $(document).foundation();
</script>