<?php
/**
 * Created by PhpStorm.
 * User: Chris-PC
 * Date: 12/8/2014
 * Time: 8:05 AM
 */

$content = file_get_contents("https://api.instagram.com/v1/media/popular");

$encoded = json_decode($content);

var_dump($encoded);

foreach ($encoded->data as $feed) {
    echo $feed->profile_picture."<br>";
}


?>